package com.junfan.grocerystore;

public class Order {
    private String order_item;
   /* private String order_amount;
    private String order_total;*/

    public String getOrder_item() {
        return order_item;
    }

    /*public String getOrder_amount() {
        return order_amount;
    }

    public String getOrder_total() {
        return order_total;
    }*/

    public void setOrder_item(String order_item) {
        this.order_item = order_item;
    }

    /*public void setOrder_amount(String order_amount) {
        this.order_amount = order_amount;
    }

    public void setOrder_total(String order_total) {
        this.order_total = order_total;
    }*/
}
